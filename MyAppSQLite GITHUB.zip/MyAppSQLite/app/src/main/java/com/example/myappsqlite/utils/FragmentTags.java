package com.example.myappsqlite.utils;

public class FragmentTags {

    public static final String MAIN_FRAGMENT_TAG = "main_frg";
    public static final String ADD_WEIGHT_FRAGMENT_TAG = "add_weight_frg";
    public static final String EDIT_WEIGHT_FRAGMENT_TAG = "edit_weight_frg";

}

package com.example.myappsqlite.ui.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myappsqlite.R;
import com.example.myappsqlite.repository.ApplicationPreferences;
import com.example.myappsqlite.repository.DatabaseHelper;
import com.example.myappsqlite.utils.AppUtils;

public class LoginActivity extends AppCompatActivity {

    EditText loginActEmailEdt, loginActPassEdt;
    RelativeLayout act_reg_have_acc_rl;
    Button loginActLoginBtn;

    DatabaseHelper dbHelper;

    @Override
    protected void onStart() {
        super.onStart();
        //Auto Login if user Exists
        if (ApplicationPreferences.getSaveSignedInUserID(LoginActivity.this) > 0) {
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(LoginActivity.this);

        act_reg_have_acc_rl = findViewById(R.id.act_reg_have_acc_rl);
        act_reg_have_acc_rl.setOnClickListener(view -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        loginActEmailEdt = findViewById(R.id.loginActEmailEdt);
        loginActPassEdt = findViewById(R.id.loginActPassEdt);
        loginActLoginBtn = findViewById(R.id.loginActLoginBtn);
        loginActLoginBtn.setOnClickListener(view -> {

            if (!AppUtils.isValidEmail(loginActEmailEdt.getText().toString().trim())) {
                loginActEmailEdt.setError("Enter a valid email");
                return;
            }

            if (loginActEmailEdt.getText().toString().trim().isEmpty()) {
                loginActEmailEdt.setError("Email cannot be empty");
                return;
            }


            if (loginActPassEdt.getText().toString().trim().isEmpty()) {
                loginActPassEdt.setError("password cannot be empty");
                return;
            }

            long userID = dbHelper.loginUser(loginActEmailEdt.getText().toString().trim(), loginActPassEdt.getText().toString().trim());
            if (userID > 0) {

                ApplicationPreferences.saveSignedInUserGoalWeight(LoginActivity.this,dbHelper.getGoalWeightOfLoginUser(
                                loginActEmailEdt.getText().toString().trim(), loginActPassEdt.getText().toString().trim()));

                Toast.makeText(this, "Logged In Successfully", Toast.LENGTH_LONG).show();
                ApplicationPreferences.saveSignedInUserID(LoginActivity.this, userID);
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            } else {
                Toast.makeText(this, "No User found with these credentials", Toast.LENGTH_LONG).show();
            }


        });
    }
}

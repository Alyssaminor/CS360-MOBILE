package com.example.myappsqlite.ui.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myappsqlite.R;
import com.example.myappsqlite.repository.ApplicationPreferences;
import com.example.myappsqlite.repository.DatabaseHelper;
import com.example.myappsqlite.utils.AppUtils;


public class RegisterActivity extends AppCompatActivity {

    EditText registerActEmailEdt,registerActUserNameEdt,registerActPassEdt,registerActConPassEdt,goalWeightKGsEDT;
    Button registerActRegBtn;
    RelativeLayout act_reg_have_acc_rl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);



        act_reg_have_acc_rl = findViewById(R.id.act_reg_have_acc_rl);
        act_reg_have_acc_rl.setOnClickListener(view->{
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
        });

        goalWeightKGsEDT = findViewById(R.id.goalWeightKGsEDT);
        registerActEmailEdt = findViewById(R.id.registerActEmailEdt);
        registerActUserNameEdt = findViewById(R.id.registerActUserNameEdt);
        registerActPassEdt = findViewById(R.id.registerActPassEdt);
        registerActConPassEdt = findViewById(R.id.registerActConPassEdt);
        registerActRegBtn = findViewById(R.id.registerActRegBtn);
        registerActRegBtn.setOnClickListener(view->{

            if(!AppUtils.isValidEmail(registerActEmailEdt.getText().toString().trim())){
                registerActEmailEdt.setError("Enter a valid email");
                return;
            }

            if(registerActEmailEdt.getText().toString().trim().isEmpty()){
                registerActEmailEdt.setError("Email cannot be empty");
                return;
            }

            if(registerActUserNameEdt.getText().toString().trim().isEmpty()){
                registerActUserNameEdt.setError("Username cannot be empty");
                return;
            }

            if(goalWeightKGsEDT.getText().toString().trim().isEmpty()){
                goalWeightKGsEDT.setError("Goal weight cannot be empty");
                return;
            }

            if(registerActPassEdt.getText().toString().trim().isEmpty()){
                registerActPassEdt.setError("password cannot be empty");
                return;
            }

            if(registerActConPassEdt.getText().toString().trim().isEmpty()){
                registerActConPassEdt.setError("password cannot be empty");
                return;
            }

            if(!registerActPassEdt.getText().toString().trim().equals(registerActConPassEdt.getText().toString().trim())){
                registerActPassEdt.setError("Both Passwords doesn't match");
                registerActConPassEdt.setError("Both Passwords doesn't match");
                return;
            }

            attemptSignup();



        });


    }

    private void attemptSignup() {
        String emailText = registerActEmailEdt.getText().toString().trim();
        String usernameText = registerActUserNameEdt.getText().toString().trim();
        String passwordText = registerActPassEdt.getText().toString().trim();
        String goalWeight = goalWeightKGsEDT.getText().toString().trim();

        if (emailText.isEmpty() || usernameText.isEmpty() || passwordText.isEmpty() || goalWeight.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_LONG).show();
            return;
        }

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        long userID = dbHelper.registerNewUser(emailText, usernameText, passwordText,goalWeight);
        if(userID>0){
            Toast.makeText(RegisterActivity.this,"User Signed up successfully",Toast.LENGTH_SHORT).show();
            ApplicationPreferences.saveSignedInUserID(RegisterActivity.this,userID);
            ApplicationPreferences.saveSignedInUserGoalWeight(RegisterActivity.this,goalWeight);
            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);

        }else{
            Toast.makeText(RegisterActivity.this,"error while inserting users values",Toast.LENGTH_SHORT).show();
        }
    }
}

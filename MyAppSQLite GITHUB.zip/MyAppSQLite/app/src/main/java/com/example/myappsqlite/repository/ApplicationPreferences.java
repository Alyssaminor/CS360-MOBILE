package com.example.myappsqlite.repository;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.SharedPreferences;

public class ApplicationPreferences {


    public static final String MY_PREFS_NAME = "WeightTracking";


    public static final String SIGNED_IN_USER_ID = "user_signedIn";
    public static final String SIGNED_IN_GOAL_WEIGHT = "user_goal_weight";


    //Set Saved Email
    public static void saveSignedInUserGoalWeight(Context mContext, String userWeight){
        SharedPreferences.Editor editor = mContext.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
        editor.putString(SIGNED_IN_GOAL_WEIGHT, userWeight);
        editor.apply();
    }


    //Get Saved Email
    public static String getSaveSignedInUserGoalWeight(Context mContext) {
        SharedPreferences prefs = mContext.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        return prefs.getString(SIGNED_IN_GOAL_WEIGHT, "");
    }

    public static void saveSignedInUserID(Context mContext, long userID){
        SharedPreferences.Editor editor = mContext.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
        editor.putLong(SIGNED_IN_USER_ID, userID);
        editor.apply();
    }


    //Get Saved Email
    public static long getSaveSignedInUserID(Context mContext) {
        SharedPreferences prefs = mContext.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        return prefs.getLong(SIGNED_IN_USER_ID, 0);
    }




    public static void clearAllPreferences(Context mContext){
        SharedPreferences prefs = mContext.getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        prefs.edit().remove(SIGNED_IN_USER_ID).apply();
        prefs.edit().remove(SIGNED_IN_GOAL_WEIGHT).apply();


    }





}

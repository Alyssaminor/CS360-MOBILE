package com.example.myappsqlite.ui.fragments;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.example.myappsqlite.R;
import com.example.myappsqlite.models.WeightModel;
import com.example.myappsqlite.repository.ApplicationPreferences;
import com.example.myappsqlite.repository.DatabaseHelper;
import com.example.myappsqlite.utils.AppUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class EditWeightEntryFragment extends Fragment {
    EditText weightDateEDT,actAddCourseTimeEDT,weightKGsEDT;
    Button updateWeightBtn;
    final Calendar myCalendar= Calendar.getInstance();

    DatabaseHelper dbHelper;

    WeightModel parsedWeightModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View frgView = inflater.inflate(R.layout.edit_weight_entry_frg,container,false);
        dbHelper = new DatabaseHelper(getActivity());





        weightKGsEDT = frgView.findViewById(R.id.weightKGsEDT);
        updateWeightBtn = frgView.findViewById(R.id.updateWeightBtn);
        updateWeightBtn.setOnClickListener(view->{


            if(weightKGsEDT.getText().toString().trim().isEmpty()){
                weightKGsEDT.setError("Weight cannot be empty");
                return;
            }

            if(actAddCourseTimeEDT.getText().toString().trim().isEmpty()){
                actAddCourseTimeEDT.setError("Select Time to proceed");
                return;
            }

            if(weightDateEDT.getText().toString().trim().isEmpty()){
                weightDateEDT.setError("Select Date to proceed");
                return;
            }

            WeightModel weightModel = new WeightModel();
            weightModel.setWeight(Double.parseDouble(weightKGsEDT.getText().toString().trim()));
            weightModel.setTime(actAddCourseTimeEDT.getText().toString().trim());
            weightModel.setDate( weightDateEDT.getText().toString().trim());
            weightModel.setUserID(ApplicationPreferences.getSaveSignedInUserID(getActivity()));


            dbHelper.updateWeightEntry(parsedWeightModel.getiD(),weightModel);

            Toast.makeText(getActivity(),"Weight Entry Updated Successfully",Toast.LENGTH_SHORT).show();



            if(Double.parseDouble(weightKGsEDT.getText().toString().trim())>=
                    Double.parseDouble(ApplicationPreferences.getSaveSignedInUserGoalWeight(getActivity()))){

                if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED) {
                    AppUtils.sendSMS(getActivity().getApplicationContext());
                }
            }

         

            weightKGsEDT.setText("");
            actAddCourseTimeEDT.setText("");
            weightDateEDT.setText("");
            getActivity().onBackPressed();

        });

        //Weight Time
        actAddCourseTimeEDT = frgView.findViewById(R.id.actAddCourseTimeEDT);
        actAddCourseTimeEDT.setOnClickListener(view->{


            Calendar mcurrentTime = Calendar.getInstance();
            int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
            int minute = mcurrentTime.get(Calendar.MINUTE);
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                    String am_pm = "";
                    if (selectedHour < 12) {
                        am_pm = "AM";
                    } else {
                        am_pm = "PM";
                    }
                    // Convert 24-hour format to 12-hour format
                    int hour_of_12_hour_format;
                    if (selectedHour > 12) {
                        hour_of_12_hour_format = selectedHour - 12;
                    } else {
                        hour_of_12_hour_format = selectedHour;
                    }
                    actAddCourseTimeEDT.setText(String.format("%02d:%02d %s", hour_of_12_hour_format, selectedMinute, am_pm));
                }
            }, hour, minute, false);//Yes 24 hour time
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();

        });



        //Weight Date
        weightDateEDT = frgView.findViewById(R.id.weightDateEDT);
        DatePickerDialog.OnDateSetListener date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);

                String myFormat="MM/dd/yy";
                SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.US);
                weightDateEDT.setText(dateFormat.format(myCalendar.getTime()));
            }
        };


        weightDateEDT.setOnClickListener(view->{
            new DatePickerDialog(getActivity(),date,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();
        });


        parsedWeightModel = (WeightModel) getArguments().getSerializable("weightModel");
        if (parsedWeightModel != null) {
            weightKGsEDT.setText(parsedWeightModel.getWeight()+"");
            actAddCourseTimeEDT.setText(parsedWeightModel.getTime());
            weightDateEDT.setText(parsedWeightModel.getDate());
        }

        return frgView;
    }

    private void sendSMS() {
        // Your code to send SMS message
        String phoneNumber = "00923255044323"; // Replace with the recipient's phone number
        String message = "Congrats, you have reached to your goal weight"; // Replace with your message

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(requireContext(), "SMS sent successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(requireContext(), "Failed to send SMS", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}

package com.example.myappsqlite.utils;

import android.content.Context;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Toast;

public class AppUtils {


    public static boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    public static void sendSMS(Context mContext) {
        // Your code to send SMS message
        String phoneNumber = "00923255044323"; // Replace with the recipient's phone number
        String message = "Congrats, you have reached to your goal weight"; // Replace with your message

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(mContext, "SMS sent successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(mContext, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}

package com.example.myappsqlite.ui.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import com.example.myappsqlite.R;
import com.example.myappsqlite.repository.ApplicationPreferences;
import com.example.myappsqlite.ui.fragments.MainFragment;
import com.example.myappsqlite.utils.FragmentTags;

public class MainActivity extends AppCompatActivity {

    ImageView logOutBTN;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        logOutBTN = findViewById(R.id.logOutBTN);
        logOutBTN.setOnClickListener(view->{
            ApplicationPreferences.clearAllPreferences(MainActivity.this);
            Intent intent = new Intent( MainActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });


        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager
                .beginTransaction()
                .replace(R.id.fragment_container, new MainFragment(), FragmentTags.MAIN_FRAGMENT_TAG)
                .commit();

    }
}
package com.example.myappsqlite;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myappsqlite.models.WeightModel;
import com.example.myappsqlite.ui.fragments.MainFragment;

import java.util.ArrayList;

public class WeightEntriesAdapter extends RecyclerView.Adapter<WeightEntriesAdapter.MyViewHolder> {

    ArrayList<WeightModel> weightModels;
    private Context mContext;
    MainFragment mainFragment;
    public WeightEntriesAdapter(Context _context, MainFragment _mainFragment,ArrayList<WeightModel> weightModels){
        this.mContext = _context;
        this.mainFragment = _mainFragment;
        this.weightModels = weightModels;
    }


    @NonNull
    @Override
    public WeightEntriesAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.weight_entry_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull WeightEntriesAdapter.MyViewHolder holder, int position) {

        holder.weightEntryDateTV.setText(weightModels.get(position).getDate());
        holder.weightEntryTimeTV.setText(weightModels.get(position).getTime());
        holder.weightTV.setText(weightModels.get(position).getWeight()+"");
        holder.weight_delete_iv.setOnClickListener(view->{
            mainFragment.onDeleteEntryClicked(weightModels.get(position));
        });

        holder.weight_edt_iv.setOnClickListener(view->{
            mainFragment.onEditEntryClicked(weightModels.get(position));
        });
    }

    @Override
    public int getItemCount() {
        return weightModels.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {


        ImageView weight_edt_iv,weight_delete_iv;
        TextView weightEntryTimeTV, weightEntryDateTV,weightTV;


        MyViewHolder(View view) {
            super(view);

            weight_edt_iv = view.findViewById(R.id.weight_edt_iv);
            weight_delete_iv = view.findViewById(R.id.weight_delete_iv);


            weightEntryTimeTV = view.findViewById(R.id.weightEntryTimeTV);
            weightEntryDateTV = view.findViewById(R.id.weightEntryDateTV);
            weightTV = view.findViewById(R.id.weightTV);


        }
    }
}

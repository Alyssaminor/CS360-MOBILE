package com.example.myappsqlite.ui.fragments;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myappsqlite.R;
import com.example.myappsqlite.WeightEntriesAdapter;
import com.example.myappsqlite.models.WeightModel;
import com.example.myappsqlite.repository.DatabaseHelper;
import com.example.myappsqlite.utils.FragmentTags;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainFragment extends Fragment {

    ArrayList<WeightModel> weightModels;
    FloatingActionButton addWeightFAB;

    DatabaseHelper dbHelper;
    RecyclerView weightEntryRV;
    WeightEntriesAdapter weightEntriesAdapter;

    private static final int SEND_SMS_PERMISSION_REQUEST_CODE = 1002;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View frgView =  inflater.inflate(R.layout.main_frg,container,false);


        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(),
                    new String[]{Manifest.permission.SEND_SMS},
                    SEND_SMS_PERMISSION_REQUEST_CODE);
        }

        dbHelper = new DatabaseHelper(getActivity());
        weightModels = dbHelper.getAllWeightEntries();

        addWeightFAB = frgView.findViewById(R.id.addWeightFAB);
        addWeightFAB.setOnClickListener(view->{
            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            fragmentManager
                    .beginTransaction()
                    .replace(R.id.fragment_container, new AddWeightEntryFragment(), FragmentTags.ADD_WEIGHT_FRAGMENT_TAG)
                    .addToBackStack(FragmentTags.ADD_WEIGHT_FRAGMENT_TAG)
                    .commit();

        });

        weightEntryRV = frgView.findViewById(R.id.weightEntryRV);
        weightEntryRV.setHasFixedSize(true);
        weightEntryRV.setLayoutManager(new LinearLayoutManager(getActivity()));

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(weightEntryRV.getContext(),
                new LinearLayoutManager(getActivity()).getOrientation());
        weightEntryRV.addItemDecoration(dividerItemDecoration);

        weightEntriesAdapter = new WeightEntriesAdapter(getActivity(),MainFragment.this,weightModels);
        weightEntryRV.setAdapter(weightEntriesAdapter);

        return frgView;
    }

    public void onDeleteEntryClicked(WeightModel weightModel) {
        dbHelper.deleteWeightEntry(weightModel.getiD());

        weightModels = dbHelper.getAllWeightEntries();
        weightEntriesAdapter = new WeightEntriesAdapter(getActivity(),MainFragment.this,weightModels);
        weightEntryRV.setAdapter(weightEntriesAdapter);
    }

    public void onEditEntryClicked(WeightModel weightModel) {

        Bundle bundle = new Bundle();
        bundle.putSerializable("weightModel", weightModel);


        EditWeightEntryFragment fragment = new EditWeightEntryFragment();

        fragment.setArguments(bundle);


        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment, FragmentTags.EDIT_WEIGHT_FRAGMENT_TAG)
                .addToBackStack(FragmentTags.EDIT_WEIGHT_FRAGMENT_TAG)
                .commit();



    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SEND_SMS_PERMISSION_REQUEST_CODE) {
            // Check if the permission is granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, you can proceed with sending SMS messages
                Toast.makeText(requireContext(), "SEND_SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                // Permission denied, inform the user
                Toast.makeText(requireContext(), "SEND_SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

package com.example.myappsqlite.repository;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.myappsqlite.models.WeightModel;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Logcat tag
    private static final String TAG = "DatabaseHelper";

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "weight_tracker.db";

    // Table Names
    private static final String TABLE_WEIGHT_ENTRIES = "weight_entries";
    private static final String TABLE_USERS = "users";

    // Common column names
    private static final String COLUMN_ID = "id";

    // WEIGHT_ENTRIES Table - column names
    private static final String COLUMN_USER_ID = "userID";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_TIME = "time";
    private static final String COLUMN_WEIGHT = "weight";

    // USERS Table - column names
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";
    private static final String COLUMN_USER_EMAIL = "user_email";
    private static final String COLUMN_PASSWORD = "password";

    // Table Create Statements
    // Weight entry table create statement
    private static final String CREATE_TABLE_WEIGHT_ENTRIES = "CREATE TABLE "
            + TABLE_WEIGHT_ENTRIES + "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_USER_ID + " INTEGER, " + COLUMN_DATE + " TEXT, " + COLUMN_TIME + " TEXT," + COLUMN_WEIGHT + " REAL" + ")";

    // User table create statement
    private static final String CREATE_TABLE_USERS = "CREATE TABLE "
            + TABLE_USERS + "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_GOAL_WEIGHT + " REAL, " +
             COLUMN_USERNAME + " TEXT," + COLUMN_USER_EMAIL + " TEXT," + COLUMN_PASSWORD + " TEXT" + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // creating required tables
        db.execSQL(CREATE_TABLE_WEIGHT_ENTRIES);
        db.execSQL(CREATE_TABLE_USERS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // on upgrade drop older tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT_ENTRIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        // create new tables
        onCreate(db);
    }

    // Method to add a weight entry
    public long addNewWeightEntry(WeightModel weightModel) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, weightModel.getUserID());
        values.put(COLUMN_DATE, weightModel.getDate());
        values.put(COLUMN_TIME, weightModel.getTime());
        values.put(COLUMN_WEIGHT, weightModel.getWeight());

        // insert row
        long weight_id = db.insert(TABLE_WEIGHT_ENTRIES, null, values);
        db.close(); // Closing database connection

        return weight_id;
    }

    public void updateWeightEntry(long id, WeightModel weightModel) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Create ContentValues object to store the new values
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, weightModel.getUserID());
        values.put(COLUMN_DATE, weightModel.getDate());
        values.put(COLUMN_TIME, weightModel.getTime());
        values.put(COLUMN_WEIGHT, weightModel.getWeight());

        // Define the WHERE clause to update the row with the specified ID
        String whereClause = COLUMN_ID + " = ?";
        String[] whereArgs = { String.valueOf(id) };

        // Perform the update operation
        db.update(TABLE_WEIGHT_ENTRIES, values, whereClause, whereArgs);

        // Close the database connection
        db.close();
    }

    public ArrayList<WeightModel> getAllWeightEntries() {
        ArrayList<WeightModel> weightList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_WEIGHT_ENTRIES;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // Loop through all rows and add to list
        if (cursor.moveToFirst()) {
            do {
                WeightModel weightModel = new WeightModel();
                weightModel.setiD(cursor.getLong(0));
                weightModel.setUserID(cursor.getLong(1));
                weightModel.setDate(cursor.getString(2) + "");
                weightModel.setTime(cursor.getString(3) + "");

                weightModel.setWeight(cursor.getDouble(4));

                // Add weightModel to list
                weightList.add(weightModel);
            } while (cursor.moveToNext());
        }

        // Close cursor and database
        cursor.close();
        db.close();

        return weightList;
    }

    public void deleteWeightEntry(long id) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Define the WHERE clause to delete the row with the specified ID
        String whereClause = COLUMN_ID + " = ?";
        String[] whereArgs = { String.valueOf(id) };

        // Perform the delete operation
        db.delete(TABLE_WEIGHT_ENTRIES, whereClause, whereArgs);

        // Close the database connection
        db.close();
    }

    // Method to add a user
    public long registerNewUser(String email,String username, String password,String goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);

        // insert row
        long user_id = db.insert(TABLE_USERS, null, values);
        db.close(); // Closing database connection

        return user_id;
    }

    // Method to check user existence
    public long loginUser(String username, String password) {
        long userID;
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + TABLE_USERS + " WHERE "
                + COLUMN_USER_EMAIL + " = ?" + " AND " + COLUMN_PASSWORD + " = ?";

        Cursor coursor = db.rawQuery(selectQuery, new String[]{username, password});
        if (coursor.moveToFirst()) {
            userID = coursor.getLong(0);
            return userID;
        } else {
            userID = 0;
            // No user found with the given username and password
        }
        boolean exists = (coursor.getCount() > 0);
        coursor.close();
        db.close();

        return userID;
    }

    public String getGoalWeightOfLoginUser(String email, String password) {
        String goalWeight = "";
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + TABLE_USERS + " WHERE "
                + COLUMN_USER_EMAIL + " = ?" + " AND " + COLUMN_PASSWORD + " = ?";

        Cursor coursor = db.rawQuery(selectQuery, new String[]{email, password});
        if (coursor.moveToFirst()) {
            //weightModel.setWeight(cursor.getDouble(4));
            goalWeight = coursor.getDouble(1) +"";
            return goalWeight;
        } else {
            goalWeight = "";
            // No user found with the given username and password
        }
        boolean exists = (coursor.getCount() > 0);
        coursor.close();
        db.close();

        return goalWeight;
    }
}
